import ClassicComponent from "./ClassicComponent"

function App() {
  return (
    <>
      <ClassicComponent initialCount={0} secondsNumber={3} />
    </>
  )
}

export default App
